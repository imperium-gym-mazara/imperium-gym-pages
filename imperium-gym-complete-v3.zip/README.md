# Imperium Gym — Complete Suite v3

حزمة Imperium Gym متصلة بمشروع Supabase الفعلي وتضم:

- `imperium-gym-frontend` — الواجهة الرئيسية
- `imperium-gym-client-portal` — بوابة العميل
- `imperium-gym-trainer-dashboard` — لوحة المدرب
- `imperium-gym-admin-dashboard` — لوحة الإدارة
- `imperium-gym-staff-scanner` — قارئ QR للموظفين

## ما تم ربطه فعليًا
- Supabase Auth للجلسات.
- بوابة العميل: الملف الشخصي، الاشتراك الفعلي، البرامج، أيام التمرين والتمارين، التغذية والوجبات، القياسات، الإشعارات، الحجوزات، وQR.
- المدرب: العملاء المعيّنون عبر `trainer_clients`، البرامج، التغذية، التقدم، والحصص والحجوزات.
- الإدارة: العملاء، الاشتراكات، الدخول، المدربون، المدفوعات، الحصص والحجوزات وإحصائيات التشغيل.
- Staff Scanner: التحقق من QR عبر Edge Function `staff-checkin`.
- Edge Functions `client-portal-v3`, `trainer-dashboard-v2`, `admin-dashboard-v2` تم تحديثها في مشروع Supabase `imperium-gym`.

## التشغيل

كل تطبيق Vite مستقل:

```bash
npm install
npm run dev
```

للتطبيقات المتصلة بـ Supabase، أنشئ `.env` من `.env.example`:

```env
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
```

## ملاحظة
الربط الخلفي تم نشره على Supabase. يبقى التحقق المحلي النهائي عبر `npm install` ثم `npm run build` لكل تطبيق قبل الإنتاج.
