# Imperium Gym — Complete Suite

هذه النسخة تجمع واجهات Imperium Gym في حزمة واحدة:

- `imperium-gym-frontend` — Member experience / main UI
- `imperium-gym-client-portal` — Client Portal connected to Supabase
- `imperium-gym-trainer-dashboard` — Trainer console connected to Supabase
- `imperium-gym-admin-dashboard` — Admin command center connected to Supabase
- `imperium-gym-staff-scanner` — Staff QR access control

## الهوية

الواجهة موحدة حول أسلوب Dark Premium / Performance مع الأسود، الفحمي، الأبيض، ومساحات عالية التباين، مع الحفاظ على اسم Imperium Gym وشكل العلامة الدائري في الواجهات.

## التشغيل

كل مشروع Vite مستقل:

```bash
npm install
npm run dev
```

وللبناء:

```bash
npm run build
```

## Supabase

المشاريع التي تعتمد على Supabase تحتاج متغيرات البيئة الموجودة في `.env.example`.

> ملاحظة: تم إجراء تعديلات الواجهة وتجهيز الحزمة، لكن بيئة التنفيذ الحالية لم تسمح بإكمال `npm install` بسبب مهلة الوصول إلى package registry؛ لذلك يلزم تشغيل `npm install` و`npm run build` محليًا أو في CI للتحقق النهائي.
